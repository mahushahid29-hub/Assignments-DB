import os
import torch
import numpy as np
from PIL import Image
from transformers import ViTImageProcessor, ViTModel
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt

IMAGE_FOLDER = "images"  # Folder containing 20-30 images
QUERY_IMAGE_PATH = "query.jpeg"  # Image to search for
MODEL_NAME = "google/vit-base-patch32-224-in21k"

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
feature_extractor = ViTImageProcessor.from_pretrained(MODEL_NAME)
model = ViTModel.from_pretrained(MODEL_NAME)
model.to(device)
model.eval()

def get_image_embedding(image_path):
    image = Image.open(image_path).convert("RGB")
    inputs = feature_extractor(images=image, return_tensors="pt")
    inputs = {k: v.to(device) for k, v in inputs.items()}

    with torch.no_grad():
        outputs = model(**inputs)
        embedding = outputs.last_hidden_state[:, 0, :].cpu().numpy()  # CLS token
    return embedding

image_paths = [
    os.path.join(IMAGE_FOLDER, f)
    for f in os.listdir(IMAGE_FOLDER)
    if f.lower().endswith((".jpg", ".jpeg", ".png"))
]

embeddings = []
for path in image_paths:
    emb = get_image_embedding(path)
    embeddings.append(emb)

embeddings = np.vstack(embeddings)
print(f"Computed embeddings for {len(embeddings)} images.")

query_embedding = get_image_embedding(QUERY_IMAGE_PATH)

print("\n===== Query Image Embedding (768 values) =====")
print(query_embedding)
print("Shape:", query_embedding.shape)

# Plot embedding as graph
plt.figure(figsize=(12, 4))
plt.plot(query_embedding[0])
plt.title("Query Image Embedding Vector (768 dimensions)")
plt.xlabel("Dimension")
plt.ylabel("Value")
plt.show()

pca = PCA(n_components=2)
reduced = pca.fit_transform(np.vstack([query_embedding, embeddings]))

plt.figure(figsize=(7, 6))
plt.scatter(reduced[1:, 0], reduced[1:, 1], label="Images")
plt.scatter(reduced[0, 0], reduced[0, 1], color="red", label="Query Image")
plt.title("PCA Visualization of Embeddings")
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.legend()
plt.show()

similarities = cosine_similarity(query_embedding, embeddings)
most_similar_idx = np.argmax(similarities)
most_similar_image_path = image_paths[most_similar_idx]

print("\nMost similar image found:", most_similar_image_path)

query_img = Image.open(QUERY_IMAGE_PATH)
result_img = Image.open(most_similar_image_path)

plt.figure(figsize=(8, 4))
plt.subplot(1, 2, 1)
plt.title("Query Image")
plt.imshow(query_img)
plt.axis("off")

plt.subplot(1, 2, 2)
plt.title("Most Similar Image")
plt.imshow(result_img)
plt.axis("off")

plt.show()
