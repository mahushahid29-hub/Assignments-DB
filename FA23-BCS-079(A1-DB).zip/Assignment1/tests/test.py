from fastapi.testclient import TestClient
from unittest.mock import patch
from app.main import app

client = TestClient(app)
def test_get_books():
    with patch("app.crud.list_books") as mock_list:
        mock_list.return_value = {
            "items": [],
            "total": 0
        }

        response = client.get("/books")

    assert response.status_code == 200
    data = response.json()
    assert "items" in data
    assert type(data["items"]) is list


def test_post_rating_auth_fail():
    # POST /ratings without API key → returns 401
    res = client.post("/ratings", json={
        "user_id": 1,
        "book_id": 2,
        "rating": 5
    })

    assert res.status_code == 401
    assert res.json()["detail"] == "Invalid or missing API key"
