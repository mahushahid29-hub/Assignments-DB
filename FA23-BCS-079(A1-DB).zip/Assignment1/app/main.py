from fastapi import FastAPI, Query, HTTPException, Depends, Request
from pydantic import BaseModel, Field
from pymongo import MongoClient
from bson import ObjectId
from datetime import datetime
import os, time, math

# --- Environment Variables ---
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "goodbooks")
API_KEY = os.getenv("API_KEY", "dev-key")

# --- MongoDB Connection ---
client = MongoClient(MONGO_URI)
db = client[DB_NAME]

# --- FastAPI App ---
app = FastAPI(title="GoodBooks API (MongoDB)", version="1.0.0")


# --- Pydantic Models ---
class RatingIn(BaseModel):
    user_id: int
    book_id: int
    rating: int = Field(ge=1, le=5)


# --- API Key Dependency ---
def require_key(req: Request):
    if req.headers.get("x-api-key") != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API key")


# --- JSON Logging Middleware ---
@app.middleware("http")
async def log_requests(request: Request, call_next):
    t0 = time.time()
    response = await call_next(request)
    latency = int((time.time() - t0) * 1000)
    log_entry = {
        "route": request.url.path,
        "params": dict(request.query_params),
        "status": response.status_code,
        "latency_ms": latency,
        "ip": request.client.host,
        "ts": datetime.utcnow().isoformat()
    }
    print(log_entry)
    return response


# --- Helper Function ---
def serialize_doc(doc):
    """Convert MongoDB _id to string for JSON serialization"""
    if not doc:
        return None
    doc["_id"] = str(doc["_id"])
    return doc


# --- Root Route ---
@app.get("/")
def root():
    return {"message": "Welcome to the GoodBooks API", "docs": "/docs"}


# --- Books List with Filters ---
@app.get("/books")
def list_books(
    q: str | None = None,
    tag: str | None = None,
    min_avg: float | None = None,
    year_from: int | None = None,
    year_to: int | None = None,
    sort: str = Query("avg", pattern="^(avg|ratings_count|year|title)$"),
    order: str = Query("desc", pattern="^(asc|desc)$"),
    page: int = 1,
    page_size: int = Query(20, le=100)
):
    filt = {}
    if q:
        filt["$or"] = [
            {"title": {"$regex": q, "$options": "i"}},
            {"authors": {"$regex": q, "$options": "i"}}
        ]
    if min_avg is not None:
        filt["average_rating"] = {"$gte": float(min_avg)}
    year_clause = {}
    if year_from is not None:
        year_clause["$gte"] = year_from
    if year_to is not None:
        year_clause["$lte"] = year_to
    if year_clause:
        filt["original_publication_year"] = year_clause

    # Tag filter via aggregation
    if tag:
        tag_match = db.tags.find_one({"tag_name": {"$regex": tag, "$options": "i"}})
        if tag_match:
            tag_id = tag_match["tag_id"]
            goodreads_ids = [bt["goodreads_book_id"] for bt in db.book_tags.find({"tag_id": tag_id})]
            filt["goodreads_book_id"] = {"$in": goodreads_ids}
        else:
            return {"items": [], "page": page, "page_size": page_size, "total": 0}

    sort_map = {
        "avg": "average_rating",
        "ratings_count": "ratings_count",
        "year": "original_publication_year",
        "title": "title"
    }
    direction = -1 if order == "desc" else 1

    total = db.books.count_documents(filt)
    items = list(db.books.find(filt)
                 .sort([(sort_map[sort], direction)])
                 .skip((page - 1) * page_size)
                 .limit(page_size))
    for x in items:
        x["_id"] = str(x["_id"])
    return {"items": items, "page": page, "page_size": page_size, "total": total}


# --- Single Book ---
@app.get("/books/{book_id}")
def get_book(book_id: int):
    book = db.books.find_one({"book_id": book_id})
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    return serialize_doc(book)


# --- Book Tags ---
@app.get("/books/{book_id}/tags")
def get_book_tags(book_id: int):
    book = db.books.find_one({"book_id": book_id})
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")

    pipeline = [
        {"$match": {"goodreads_book_id": book["goodreads_book_id"]}},
        {"$lookup": {
            "from": "tags",
            "localField": "tag_id",
            "foreignField": "tag_id",
            "as": "tag_info"
        }},
        {"$unwind": "$tag_info"},
        {"$project": {"_id": 0, "tag_id": 1, "tag_name": "$tag_info.tag_name", "count": 1}}
    ]
    tags = list(db.book_tags.aggregate(pipeline))
    return {"book_id": book_id, "tags": tags}


# --- Author Books ---
@app.get("/authors/{author_name}/books")
def get_author_books(author_name: str):
    books = list(db.books.find(
        {"authors": {"$regex": author_name, "$options": "i"}},
        {"_id": 0}
    ))
    return {"author": author_name, "books": books}


# --- Tags List with Counts ---
@app.get("/tags")
def list_tags(page: int = 1, page_size: int = Query(20, le=100)):
    pipeline = [
        {"$lookup": {
            "from": "book_tags",
            "localField": "tag_id",
            "foreignField": "tag_id",
            "as": "usage"
        }},
        {"$project": {
            "_id": 0,
            "tag_id": 1,
            "tag_name": 1,
            "book_count": {"$size": "$usage"}
        }},
        {"$skip": (page - 1) * page_size},
        {"$limit": page_size}
    ]
    tags = list(db.tags.aggregate(pipeline))
    total = db.tags.count_documents({})
    return {"items": tags, "page": page, "page_size": page_size, "total": total}


# --- User To-Read List ---
@app.get("/users/{user_id}/to-read")
def get_user_to_read(user_id: int):
    entries = list(db.to_read.find({"user_id": user_id}, {"_id": 0, "book_id": 1}))
    book_ids = [x["book_id"] for x in entries]
    books = list(db.books.find({"book_id": {"$in": book_ids}}, {"_id": 0}))
    return {"user_id": user_id, "to_read": books}


# --- Ratings Summary ---
@app.get("/books/{book_id}/ratings/summary")
def get_ratings_summary(book_id: int):
    ratings = list(db.ratings.find({"book_id": book_id}, {"_id": 0, "rating": 1}))
    if not ratings:
        return {"book_id": book_id, "average": 0, "count": 0, "histogram": {}}

    count = len(ratings)
    avg = round(sum(x["rating"] for x in ratings) / count, 2)
    hist = {i: sum(1 for x in ratings if x["rating"] == i) for i in range(1, 6)}
    return {"book_id": book_id, "average": avg, "count": count, "histogram": hist}


# --- Upsert Rating (Protected) ---
@app.post("/ratings", dependencies=[Depends(require_key)])
def upsert_rating(r: RatingIn):
    res = db.ratings.update_one(
        {"user_id": r.user_id, "book_id": r.book_id},
        {"$set": r.model_dump()},
        upsert=True
    )
    return {"upserted": bool(res.upserted_id), "matched": res.matched_count}


# --- Health Endpoint ---
@app.get("/healthz")
def health_check():
    try:
        db.command("ping")
        return {"status": "ok", "mongo": "connected"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
