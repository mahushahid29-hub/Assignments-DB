import pandas as pd
from pymongo import MongoClient, InsertOne
import os

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "goodbooks")

client = MongoClient(MONGO_URI)
db = client[DB_NAME]

def load_csv(url, dtype=None):
    try:
        return pd.read_csv(url, dtype=dtype).fillna("")
    except Exception as e:
        print(f" Failed to read CSV: {url}\nReason: {e}")
        return pd.DataFrame()


def import_csv(collection, url, dtype=None):
    df = load_csv(url, dtype)

    if df.empty:
        print(f" No data found for: {collection}")
        return

    operations = [InsertOne(row) for row in df.to_dict("records")]

    db[collection].delete_many({})
    db[collection].bulk_write(operations)

    print(f"Imported {len(operations)} documents into '{collection}'")

def main():
    import_csv("books",      "https://raw.githubusercontent.com/zygmuntz/goodbooks-10k/master/samples/books.csv")
    import_csv("ratings",    "https://raw.githubusercontent.com/zygmuntz/goodbooks-10k/master/samples/ratings.csv")
    import_csv("tags",       "https://raw.githubusercontent.com/zygmuntz/goodbooks-10k/master/samples/tags.csv")
    import_csv("book_tags",  "https://raw.githubusercontent.com/zygmuntz/goodbooks-10k/master/samples/book_tags.csv")
    import_csv("to_read",    "https://raw.githubusercontent.com/zygmuntz/goodbooks-10k/master/samples/to_read.csv")

if __name__ == "__main__":
    main()
