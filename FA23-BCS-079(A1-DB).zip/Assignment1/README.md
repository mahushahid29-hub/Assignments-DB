**GoodBooks API — FastAPI + MongoDB**
A clean, production-ready API for browsing books, searching, filtering, rating books, and working with the GoodBooks dataset — backed by MongoDB and FastAPI.

**Features**

FastAPI backend

MongoDB database

Search books by title, author, rating, or year

Pagination, filtering, sorting

Protected /ratings endpoint with API key

CSV ingestion script to load GoodBooks dataset

Dockerized for easy deployment

**Requirements**

Python 3.11

MongoDB (local or Docker)

pip / virtual environment

**Setup (Local Without Docker)**

Create & activate virtual environment

python -m venv .venv

.venv\Scripts\activate

**Install dependencies**

pip install -r requirements.txt

Start MongoDB locally

Make sure MongoDB is running at:

mongodb://localhost:27017

Load GoodBooks dataset

python ingest/load_data.py

Start FastAPI

uvicorn app.main:app --reload


API is now live:

http://127.0.0.1:8000/docs

**Run Everything With Docker (Recommended)**

Build & start all services

docker compose up --build -d

**Check running containers**

docker ps

Load data into MongoDB inside Docker

docker exec -it pythonproject7-api-1 python ingest/load_data.py

API Key (For POST /ratings)

Add header:

x-api-key: secret123


You can change the key inside app/deps.py.

**Ingest Script Explained**

The script downloads GoodBooks CSV files from GitHub and imports them into MongoDB:

python ingest/load_data.py


